#ifndef BIN_H
#define BIN_H

class Bin
{
public:
    Bin();
};

#endif // BIN_H
