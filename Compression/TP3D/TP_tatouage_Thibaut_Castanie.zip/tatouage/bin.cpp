#include "bin.h"

Bin::Bin()
{
}
