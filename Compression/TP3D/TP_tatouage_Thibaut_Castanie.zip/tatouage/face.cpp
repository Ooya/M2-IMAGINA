#include "face.h"

Face::Face()
{
}

Face::Face(Point a, Point b, Point c){
    this->a = a;
    this->b = b;
    this->c = c;
}
